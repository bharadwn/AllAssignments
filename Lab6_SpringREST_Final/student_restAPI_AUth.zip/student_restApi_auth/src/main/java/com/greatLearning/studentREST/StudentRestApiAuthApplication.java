package com.greatLearning.studentREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRestApiAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRestApiAuthApplication.class, args);
	}

}
