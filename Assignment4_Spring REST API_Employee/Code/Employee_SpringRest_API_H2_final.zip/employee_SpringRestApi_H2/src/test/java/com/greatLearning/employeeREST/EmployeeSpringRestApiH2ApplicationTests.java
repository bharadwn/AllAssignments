package com.greatLearning.employeeREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSpringRestApiH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
